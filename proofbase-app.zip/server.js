// Proofbase prototype server — serves the page and streams AI drafts.
// No dependencies. Node 20+.  Run:  node --env-file=.env server.js
const http = require("http");
const fs = require("fs");
const path = require("path");
const PROMPTS = require("./public/prompts.js");

const PORT = process.env.PORT || 8080;
const PUBLIC = path.join(__dirname, "public");
const MAX_BODY = 64 * 1024;

/* ---------- Model provider (pick by env) ---------- */
function provider() {
  const p = (process.env.PROVIDER || "").toLowerCase();
  if ((p === "azure-openai" || !p) && process.env.AZURE_OPENAI_ENDPOINT && process.env.AZURE_OPENAI_DEPLOYMENT)
    return { id: "azure-openai", label: "Azure OpenAI" };
  if ((p === "anthropic" || !p) && process.env.ANTHROPIC_API_KEY)
    return { id: "anthropic", label: "Claude" };
  return null;
}

// Reads an upstream SSE response and calls onData(jsonObject) per event.
async function readSSE(res, onData) {
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (!payload || payload === "[DONE]") continue;
      let obj;
      try { obj = JSON.parse(payload); } catch { continue; /* ignore keep-alives */ }
      onData(obj);
    }
  }
}

async function streamAzureOpenAI(prompt, onDelta, signal) {
  const base = process.env.AZURE_OPENAI_ENDPOINT.replace(/\/+$/, "");
  const url = `${base}/openai/deployments/${encodeURIComponent(process.env.AZURE_OPENAI_DEPLOYMENT)}/chat/completions?api-version=${process.env.AZURE_OPENAI_API_VERSION || "2024-10-21"}`;
  const headers = { "Content-Type": "application/json" };
  if (process.env.AZURE_OPENAI_API_KEY) headers["api-key"] = process.env.AZURE_OPENAI_API_KEY;
  else if (process.env.AZURE_OPENAI_BEARER) headers["Authorization"] = `Bearer ${process.env.AZURE_OPENAI_BEARER}`;
  const res = await fetch(url, {
    method: "POST", headers, signal,
    body: JSON.stringify({
      stream: true, temperature: 0.3, max_tokens: 800,
      messages: [
        { role: "system", content: "You draft concise, factual consulting documents. Use only the facts provided." },
        { role: "user", content: prompt },
      ],
    }),
  });
  if (!res.ok) throw new Error(`Azure OpenAI ${res.status}: ${(await res.text()).slice(0, 200)}`);
  await readSSE(res, (j) => { const d = j.choices?.[0]?.delta?.content; if (d) onDelta(d); });
}

async function streamAnthropic(prompt, onDelta, signal) {
  const base = (process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com").replace(/\/+$/, "");
  const res = await fetch(`${base}/v1/messages`, {
    method: "POST", signal,
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
      max_tokens: 800, stream: true,
      system: "You draft concise, factual consulting documents. Use only the facts provided.",
      messages: [{ role: "user", content: prompt }],
    }),
  });
  if (!res.ok) throw new Error(`Anthropic ${res.status}: ${(await res.text()).slice(0, 200)}`);
  await readSSE(res, (j) => {
    if (j.type === "content_block_delta" && j.delta?.type === "text_delta") onDelta(j.delta.text);
    if (j.type === "error") throw new Error(j.error?.message || "stream error");
  });
}

/* ---------- HTTP ---------- */
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json", ".svg": "image/svg+xml", ".png": "image/png" };

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", (c) => { size += c.length; if (size > MAX_BODY) { reject(new Error("too large")); req.destroy(); } else chunks.push(c); });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

async function handleDraft(req, res) {
  const p = provider();
  if (!p) { res.writeHead(503, { "Content-Type": "application/json" }); return res.end(JSON.stringify({ error: "No model configured" })); }
  let body;
  try { body = JSON.parse(await readBody(req)); } catch { res.writeHead(400); return res.end("Bad request"); }
  const build = PROMPTS[body && body.task];
  if (!build || typeof body.data !== "object") { res.writeHead(400); return res.end("Unknown task"); }
  const prompt = build(body.data); // prompts are built here, so the endpoint can't be used as an open model proxy

  res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive", "X-Provider": p.id });
  const ac = new AbortController();
  res.on("close", () => ac.abort());
  const send = (o) => res.write(`data: ${JSON.stringify(o)}\n\n`);
  try {
    const fn = p.id === "azure-openai" ? streamAzureOpenAI : streamAnthropic;
    await fn(prompt, (delta) => send({ delta }), ac.signal);
    send({ done: true });
  } catch (e) {
    if (!ac.signal.aborted) { console.error(e.message); send({ error: "The model call failed. Check server logs." }); }
  }
  res.end();
}

function serveStatic(req, res) {
  const urlPath = decodeURIComponent(new URL(req.url, "http://x").pathname);
  const file = path.normalize(path.join(PUBLIC, urlPath === "/" ? "index.html" : urlPath));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    const ext = path.extname(file);
    // index.html is authored without a doctype (so it can also be published as a claude.ai artifact); add one here.
    if (ext === ".html" && !/^\s*<!doctype/i.test(buf.toString("utf8", 0, 30)))
      buf = Buffer.concat([Buffer.from('<!doctype html><html lang="en"><head><meta charset="utf-8"></head><body>'), buf, Buffer.from("</body></html>")]);
    res.writeHead(200, { "Content-Type": TYPES[ext] || "application/octet-stream", "X-Content-Type-Options": "nosniff" });
    res.end(buf);
  });
}

http.createServer(async (req, res) => {
  try {
    if (req.method === "GET" && req.url === "/api/health") {
      const p = provider();
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ ok: true, provider: p ? p.id : null, label: p ? p.label : null }));
    }
    if (req.method === "POST" && req.url === "/api/draft") return handleDraft(req, res);
    if (req.method === "GET") return serveStatic(req, res);
    res.writeHead(405); res.end();
  } catch (e) {
    console.error(e); if (!res.headersSent) res.writeHead(500); res.end();
  }
}).listen(PORT, () => {
  const p = provider();
  console.log(`Proofbase on http://localhost:${PORT}  ·  drafts: ${p ? p.label : "sample text (no model configured)"}`);
});
