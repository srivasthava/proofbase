/* Shared prompt builders — used by the page (inside claude.ai) and by server.js (outside it). */
(function (root) {
  const clip = (s, n) => String(s == null ? "" : s).slice(0, n);
  const list = (a, n, len) => (Array.isArray(a) ? a : []).slice(0, n).map(x => clip(x, len));

  const PROMPTS = {
    report(d) {
      return [
        "You write weekly client status reports for a consulting engagement. Write a concise report for the client's program manager.",
        `Project: ${clip(d.project, 120)} for ${clip(d.client, 120)}. ${clip(d.week, 60)}. Overall status: ${clip(d.health, 20)}.`,
        `Last week: ${list(d.lastWeek, 12, 300).join("; ")}.`,
        `Confirmed delivered this week: ${list(d.delivered, 20, 300).join("; ")}.`,
        `Risks: ${list(d.risks, 10, 300).join("; ")}.`,
        "Format as plain text. Put each of these headings on its own line, exactly: Summary, Delivered this week, Compared with last week, Next week, Risks and decisions needed.",
        "Under each heading use lines starting with \"- \" (Summary may be one short paragraph). Under 220 words. Use only the facts given; do not invent numbers. No other markdown.",
      ].join("\n");
    },
    rfp(d) {
      const src = (Array.isArray(d.sources) ? d.sources : []).slice(0, 5)
        .map((s, i) => `[${i + 1}] (${clip(s.kind, 30)}; ${clip(s.meta, 160)}) ${clip(s.title, 160)}: ${clip(s.text, 900)}`).join("\n");
      return [
        "Draft a proposal response of about 150 words to this RFP requirement, using ONLY the numbered sources below.",
        "Cite sources inline as [1], [2]. Do not invent clients, numbers or claims beyond the sources. Plain text, no markdown.",
        "End with one line starting \"Sources:\" that lists the numbers used.",
        `Requirement: ${clip(d.requirement, 1500)}`,
        "Sources:",
        src,
      ].join("\n");
    },
  };

  if (typeof module !== "undefined" && module.exports) module.exports = PROMPTS;
  else root.PROMPTS = PROMPTS;
})(typeof window !== "undefined" ? window : this);
