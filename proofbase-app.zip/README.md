# Proofbase prototype

A clickable prototype of the Proofbase workflow: onboard a project, weekly check-in, AI-drafted client report, quals harvest, RFP matching, Design Atlas (including app modernization patterns) and MCP access.

**All clients, projects and figures in the sample data are fictional.**

## How drafting works

The client report and RFP response stream in word by word, from the first source that is available:

| Where the page runs | Who writes the draft |
| --- | --- |
| Inside claude.ai (as an artifact) | Claude, after the viewer allows it |
| This server, with a model configured | Your model via `/api/draft` (Azure OpenAI or Claude) |
| This server with no model, or a static host | A sample draft, typed out with the same animation |

Prompts are built on the server from structured data (`public/prompts.js`), so `/api/draft` can't be used as an open proxy to the model. API keys stay on the server and never reach the browser.

## Run locally

Requires Node 20.6+ and no npm packages.

```bash
cp .env.example .env      # fill in one provider, or leave blank for sample drafts
npm run dev               # http://localhost:8080
```

## Deploy to Azure App Service

```bash
az login
az webapp up --name proofbase-demo --runtime "NODE:20-lts" --sku B1 --location eastus
az webapp config appsettings set --name proofbase-demo --resource-group <rg> --settings \
  AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com \
  AZURE_OPENAI_DEPLOYMENT=<deployment> \
  AZURE_OPENAI_API_KEY=@Microsoft.KeyVault(SecretUri=https://<vault>.vault.azure.net/secrets/aoai-key/)
```

Then, before anyone else opens it:

1. **Require sign-in.** In the portal, open the app → Authentication → Add identity provider → Microsoft (Entra ID). Set unauthenticated requests to "HTTP 302 redirect". This keeps the page and `/api/draft` behind your organization's login.
2. **Keep secrets in Key Vault.** Use the Key Vault reference shown above and give the app's managed identity `get` access to secrets.
3. **Prefer keyless auth** where your policy requires it: use managed identity with Azure OpenAI and pass a token as `AZURE_OPENAI_BEARER` (or extend `server.js` to fetch one).

Or with Docker:

```bash
docker build -t proofbase .
docker run -p 8080:8080 --env-file .env proofbase
```

## Files

```
public/index.html   the whole UI and sample data
public/prompts.js   prompt builders shared by the page and the server
server.js           static hosting + /api/health + /api/draft (streams Server-Sent Events)
sample-files/       the sample documents as standalone files
```

## Next steps toward a real build

- Replace the in-page sample data with a store (Azure SQL or Postgres + vector search).
- Add ingestion: Graph API connectors for SharePoint and Teams, Azure DevOps API, Document Intelligence for PDFs and decks.
- Expose the knowledge base as an MCP server with the tools shown on the MCP page.
- Before using real client data, clear it with Risk, OGC and Data Privacy.
