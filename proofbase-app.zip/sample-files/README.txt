Proofbase sample data set. All clients, projects and figures are fictional.
Use these files to seed a real ingestion pipeline or demo.
