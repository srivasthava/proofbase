---
name: aidi-knowledge-base
description: Build and use the AIDI (AI Delivery Intelligence) knowledge base. Use when turning engagement material (SOWs, status reports, board exports, architecture docs, past RFP/RFI responses) into structured records, drafting a weekly client report, harvesting quals, answering an RFP requirement from past work, or writing a Design Atlas card.
---

# AIDI knowledge base

AIDI captures what engagement teams deliver and turns it into reusable proof. This skill covers five jobs:

| Job | Trigger phrases | Output |
| --- | --- | --- |
| 1. Onboard a project | "onboard this project", a SOW or kickoff deck | A **Project frame** record |
| 2. Capture the week | "weekly check-in", a status report or board export | **Weekly entries**, each tagged |
| 3. Draft the client report | "draft the weekly report", "this week vs last week" | A **client report** in the fixed format |
| 4. Harvest quals | "harvest quals", "what can we reuse from this week" | **Qual** records, status `proposed` |
| 5. Answer an RFP requirement | an RFP/RFI question, "find past work for…" | Ranked **matches** and a **cited draft** |
| 6. Write a design card | an architecture doc, "add this to the Design Atlas" | A **Design card** record |

`references/sample-data.md` holds a complete fictional example of every record and one worked example per job. Read it before producing a record type for the first time in a conversation, and match its shape exactly.

## Ground rules (apply to every job)

1. **Use only facts in the source material.** Never invent numbers, dates, client names, outcomes or technologies. If a field has no source, leave it `null` and list it under `open_questions`.
2. **Every fact carries evidence.** Each record cites where it came from: a ticket id, file name and section, or meeting date. No evidence, no qual.
3. **Client confidentiality.**
   - Records inside a project may name the client.
   - Anything reusable outside the project (quals, RFP drafts, Atlas proof lines) uses a **generalized descriptor**: "a state human-services agency", "a federal records office", never the client's name, people's names, internal system names, contract numbers or dollar values from the contract.
   - Mark each record's `sensitivity`: `internal`, `client-confidential` or `reusable`.
4. **People approve; AI proposes.** Quals and design-card promotions are always created with status `proposed`. Only a named human reviewer moves them to `approved` or `rejected`. Never mark something approved yourself.
5. **No training language.** Do not suggest that records are used to train or fine-tune a model. Improvement comes from stored feedback (examples, rules, rankings, checklists).
6. **Plain, specific writing.** Active voice, numbers with units, no adjectives doing the work of evidence ("significantly improved" → "cut p95 latency from 1.2 s to 410 ms").

## Taxonomy

Tag every record with one `category` and any number of `tech` values.

**Categories:** Cloud migration · App modernization · Mainframe modernization · Data & analytics · AI & GenAI · Security & compliance · DevSecOps · Platform engineering · Program governance · Organizational change · Testing & quality · Operations & support

**Artifact types** (for Weekly entries and evidence): Deliverable · Runbook · Architecture · Governance · Presentation · Decision · Risk · Outcome · Operations · In progress

**Maturity** (Design cards only): `draft` → `reviewed` → `proven` → `gold`
- `reviewed` needs an architecture review board decision.
- `proven` needs at least one engagement with linked evidence and a published build kit.
- `gold` needs everything for `proven`, plus reuse on more than one engagement and a cost model.

## Record schemas

Write records as JSON in fenced code blocks unless the user asks for another format. Field names are fixed.

### Project frame
```json
{
  "record": "project_frame",
  "project_id": "P-###",
  "name": "",
  "client": "",
  "client_descriptor": "generalized, reusable description of the client",
  "sector": "Civil | Defense, Security & Justice | Federal Health | State, Local & Higher Ed | Commercial",
  "scope": ["one line per scope item"],
  "tech": [],
  "modernization_pattern": null,
  "governance": {"steering": null, "change_board": null, "cadence": null, "status_reporting": null},
  "team_size": null,
  "start_date": null,
  "evidence": [],
  "open_questions": []
}
```

### Weekly entry
```json
{
  "record": "weekly_entry",
  "project_id": "P-###",
  "week": "YYYY-Www",
  "text": "one sentence, past tense, with the number that matters",
  "artifact_type": "Deliverable",
  "category": "",
  "tech": [],
  "metrics": {},
  "evidence": [],
  "confirmed_by": null,
  "sensitivity": "client-confidential"
}
```
`confirmed_by` stays `null` until a workstream lead confirms. Items still in progress use `artifact_type: "In progress"` and are not harvested.

### Qual
```json
{
  "record": "qual",
  "qual_id": "Q-###",
  "project_id": "P-###",
  "category": "",
  "statement": "1–2 sentences, generalized client, outcome with numbers",
  "metric": "short form of the headline number",
  "tech": [],
  "evidence": [],
  "sensitivity": "reusable",
  "status": "proposed",
  "reviewer": null,
  "review_note": null
}
```

### Past answer (from historical RFP/RFI responses)
```json
{
  "record": "past_answer",
  "answer_id": "A-###",
  "question": "the requirement as asked",
  "answer": "the response text, generalized",
  "client_descriptor": "",
  "year": 2025,
  "outcome": "Won | Lost | Pending | Unknown",
  "category": "",
  "tags": [],
  "source": "file name and section"
}
```

### Design card
```json
{
  "record": "design_card",
  "design_id": "D-###",
  "name": "",
  "category": "",
  "cloud": "Azure | AWS | GCP | Hybrid",
  "context": "the problem this design solves, one sentence",
  "components": [{"lane": "", "name": "", "detail": ""}],
  "decisions": [{"decision": "", "why": ""}],
  "nfr": [],
  "compliance": [],
  "cost": null,
  "effort": null,
  "build_kit": [],
  "proof": [{"engagement_descriptor": "", "project_id": null, "evidence": []}],
  "maturity": "draft",
  "source": "harvested | submitted | hackathon",
  "owners": []
}
```

## Job 1 · Onboard a project

1. Read the SOW, kickoff deck and any architecture document provided.
2. Fill the **Project frame**. Pull scope as one line per item, tech exactly as named in the source, and governance cadences word for word.
3. Write `client_descriptor` now, so later reusable records stay consistent.
4. List missing fields under `open_questions` and ask the user up to three of them, most important first.

## Job 2 · Capture the week

1. From a status report, board export or the user's notes, create one **Weekly entry** per delivered item.
2. Rewrite each as one past-tense sentence that keeps the number (`"47 minutes of read-only downtime"`, not `"minimal downtime"`).
3. Tag `artifact_type`, `category` and `tech` against the project frame.
4. Put measured values in `metrics` with units in the key (`"downtime_min": 47`).
5. Present the list as a checklist for the lead to confirm. Do not set `confirmed_by` yourself.

## Job 3 · Draft the client report

Use confirmed entries for this week and last week's report or entries. Write plain text with exactly these headings, each on its own line:

```
Summary
Delivered this week
Compared with last week
Next week
Risks and decisions needed
```

- **Summary:** one or two sentences, the single most important outcome first.
- **Delivered this week:** one bullet per confirmed entry.
- **Compared with last week:** what moved, with before and after numbers.
- **Next week:** only items the source names; otherwise write `- [to confirm with lead]`.
- **Risks and decisions needed:** carry open risks with id and owner; state any decision needed as a question.
- Under 250 words. The client's name may appear here; this report goes to the client.

## Job 4 · Harvest quals

1. Consider only confirmed entries with a measurable outcome or a clear capability shown.
2. Skip: in-progress items, internal admin, anything without evidence.
3. Write each **Qual** statement as: *[action verb] [what] for [generalized client], [result with number].*
4. Run the confidentiality check from the ground rules on every statement before output.
5. Status is always `proposed`. Present them for approval, each with its evidence.

## Job 5 · Answer an RFP requirement

1. Break the requirement into its asks (for example: approach, experience, data migration, security).
2. Search the available records (approved quals first, then past answers, then design cards). Rank by how many asks a record covers, then by recency, then by outcome `Won`.
3. Show the top three to five matches as a table: rank, record type, title, why it matches, evidence.
4. Draft a response of about 150 words using **only** the matched records. Cite each claim inline as `[1]`, `[2]`, and end with a `Sources:` line mapping numbers to record ids.
5. If an ask has no matching record, say so in a line after the draft (`No past work found for: …`) instead of filling the gap.
6. Never cite a qual whose status is not `approved`.

## Job 6 · Write a design card

1. From an architecture document, list components by lane (for example Source → Transfer → Target → Operate), with one line of configuration detail each.
2. Record each architectural choice as a decision with its reason. Include the alternative that was rejected when the source names it.
3. Copy NFRs, compliance targets, cost and effort only from the source.
4. Set `maturity` from the rules in the taxonomy, never higher. A new submission or hackathon entry is `draft`.
5. Proof lines use generalized descriptors and link evidence.

## Feedback the skill should apply

When the user edits or rejects output, adjust within the conversation and say what you changed:
- An edited draft → match its length, tone and level of detail in the next draft.
- A rejected qual with a reason → do not propose similar statements again in this conversation.
- A corrected tag → use the corrected category or tech for similar items.

## Quality checklist (run before every answer)

- [ ] Every number appears in the source material.
- [ ] Every record has evidence.
- [ ] No client name, person name or contract value in a `reusable` record.
- [ ] Quals and promotions are `proposed`, not `approved`.
- [ ] RFP drafts cite only approved quals and listed past answers.
- [ ] Field names match the schemas above.
